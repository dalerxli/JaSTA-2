gfortran polydisperse.f90 -o poly
chmod u+x poly
./poly

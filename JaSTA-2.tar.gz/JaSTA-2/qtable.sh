cd QTABLE
cat opt*.out > output.out
cd ..
mv QTABLE/output.out output.out

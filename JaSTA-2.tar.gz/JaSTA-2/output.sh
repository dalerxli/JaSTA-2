cd OUTPUT
cat test*.out > output.dat
cd ..
mv OUTPUT/output.dat output.dat

 f95 nsphere.for -o nsphere
  ./nsphere inp.text
 f95 csca.for -o csca
 ./csca

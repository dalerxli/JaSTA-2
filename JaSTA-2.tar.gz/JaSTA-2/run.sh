gfortran run2.for -o run2
./run2

 f95 spline.f90 -o spline
  ./spline
 f95 splinek.f90 -o splinek
 ./splinek 
 f95 wavesort.f90 -o wavesort
 ./wavesort 
